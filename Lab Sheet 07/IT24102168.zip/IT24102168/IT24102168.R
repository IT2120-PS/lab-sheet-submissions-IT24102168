setwd("//Users//ahamedhfarajeen//Desktop//IT24102168")

#Problem 01
a <- 10
b <- 25
total_interval <- 40
p <- (b-a)/total_interval
p

#Problem 02 
lambda <- 1/3
x <- 2
P_update <- 1 - exp(-lambda*x)
P_update

#Problem 03 
#i. 
mu <- 100
sigma <- 15
X <- 130
Z <- (X - mu)/sigma
P_IQ_above_130 <- 1 - pnorm(Z)
P_IQ_above_130

#ii.
percentile_95 <- qnorm(0.95, mean = mu, sd = sigma)
percentile_95


